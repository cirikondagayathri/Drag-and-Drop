import React, { Component } from 'react';
import { render } from 'react-dom';
import { Panel } from "./panel";
import { drag, drop } from "./Drop";
import './index.css';

const Button = drag(() => <button>Drag Me</button>)('hello world')
const DropArea = drop(Panel);

class App extends Component {
  render() {
    return (
      <div>
        <Button />
        <DropArea></DropArea>
        <hr />
        <DropArea></DropArea>
        <hr />
        
      </div>
    );
  }
}
render(<App/>, document.getElementById('root')
);