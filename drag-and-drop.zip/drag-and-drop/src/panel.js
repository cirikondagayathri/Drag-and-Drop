import React from 'react';

export class Panel extends React.Component {
  render() {
    const { list } = this.props;
    return (
      <div style={{ width: '100px', height: '100px'}}>
        
        <div>Items: {list.length}</div>
        {list.map((el, i) => <div key={i}>{el}</div>)}

      </div>
    )
  }
}